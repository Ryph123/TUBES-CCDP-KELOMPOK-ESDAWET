public class Sepatu implements Laundry{

    String jenislaundry = "";

    public String getJenislaundry() {
        return jenislaundry;
    }

    public void setJenislaundry(String jenislaundry) {
        this.jenislaundry = jenislaundry;
    }

    @Override
    public void getResponseText() {
            System.out.println("Cuci Sepatu Reguler");
            System.out.println("Harga RP. 35.000 / per pasang");
            System.out.println("Lama pekerjaan 6 hari");
            System.out.println("Cuci Sepatu Ekspress");
            System.out.println("Harga RP. 100.000 / per pasang");
            System.out.println("Lama pekerjaan 2 hari");
    }
}

public class LaundryClient {
    public static void main(String[] args) {
        LaundryFactory laundryFactory = new LaundryFactory();
        Laundry sepatu = laundryFactory.getLaundry("sepatu");
        Laundry kiloan = laundryFactory.getLaundry("kiloan");

        sepatu.getResponseText();
        kiloan.getResponseText();
    }
}

public class Kiloan implements Laundry {
    String jenislaundry = "";

    public String getJenislaundry() {
        return jenislaundry;
    }

    public void setJenislaundry(String jenislaundry) {
        this.jenislaundry = jenislaundry;
    }

    @Override
    public void getResponseText() {
            System.out.println("Cuci Kiloan Reguler");
            System.out.println("Harga RP. 6.000 / per Kg");
            System.out.println("Lama pekerjaan 4 hari");
            System.out.println("Cuci Kiloan Ekspress");
            System.out.println("Harga RP. 10.000 / per Kg");
            System.out.println("Lama pekerjaan 1 hari");
    }
}

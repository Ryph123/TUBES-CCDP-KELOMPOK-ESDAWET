public interface Laundry {
    void getResponseText();
}

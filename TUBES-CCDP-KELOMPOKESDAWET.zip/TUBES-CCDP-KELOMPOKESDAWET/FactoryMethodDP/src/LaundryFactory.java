public class LaundryFactory {
    public Laundry getLaundry(String message) {
        if(message.equalsIgnoreCase("sepatu"))
            return new Sepatu();
        else if(message.equalsIgnoreCase("kiloan"))
            return new Kiloan();
        else
            return null;
    }
}

package Singleton;

import java.util.Scanner;

public class LaundryChatbotClient {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String inputMessage = "";
        Laundry laundry = Laundry.getLaundry();
        while(!inputMessage.equals("keluar")) {
            inputMessage = scanner.nextLine();
            laundry.chatbotMessage(inputMessage);
        }
    }
}

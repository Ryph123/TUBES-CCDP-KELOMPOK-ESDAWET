package Singleton;

public class Laundry {
    private static Laundry laundry;

    private Laundry() {
        System.out.println("Halo kak, aku laundry. ada yang bisa aku bantu?");
        System.out.println("Tanyakan *service untuk tahu service aku, dan *keluar untuk selesaikan chat kita :(");
    }

    public static synchronized Laundry getLaundry(){
        if(laundry == null) {
            laundry = new Laundry();
        }

        return laundry;
    }

    public void chatbotMessage(String message) {
        switch (message) {
            case "service" :
                System.out.println("Halo kak, ini service yang aku sediakan :");
                System.out.println("1. Laundry Sepatu Premium (Rp. 35.000 / 3 hari)");
                System.out.println("2. Laundry Reguler (Rp. 6000 per Kg / 3 hari");
                System.out.println("3. Laundry Ekspress (Rp. 10.000 per Kg / 1 hari");
                break;
            case "keluar" :
                System.out.println("Selamat jalan, aku akan selalu ada menemani kamu untuk meng-laundry ~");
                break;
            default :
                System.out.println("untuk yang lain belum ada kak, silahkan tanyakan yang ada dulu..");
        }
    }
}

public class KiloanEkspress implements Kiloan {
    private String jenisLaundry = KiloanEkspress.class.getSimpleName();


    @Override
    public void jenisLaundry() {
        System.out.println("Jenis Laundry : "+jenisLaundry);
    }

    @Override
    public void harga() {
        System.out.println("Harga Laundry : RP. 10.000 / Kg");
    }
}

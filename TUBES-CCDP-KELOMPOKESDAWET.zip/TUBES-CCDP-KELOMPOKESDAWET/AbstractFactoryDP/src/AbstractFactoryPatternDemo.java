public class AbstractFactoryPatternDemo {
    public static void main(String[] args) {
        // memilih laundry sepatu
        AbstractFactory laundrySepatu = FactoryLaundry.getFactory(FactoryLaundry.pilih_sepatu);
        Sepatu sepatu1 = laundrySepatu.getSepatu(JenisSepatu.sepatuRegular);
        sepatu1.jenisLaundry();
        sepatu1.harga();

        Sepatu sepatu2 = laundrySepatu.getSepatu(JenisSepatu.sepatuEkspress);
        sepatu2.jenisLaundry();
        sepatu2.harga();

        // memilih laundry kiloan
        AbstractFactory laundryKiloan = FactoryLaundry.getFactory(FactoryLaundry.pilih_kiloan);
        Kiloan kiloan1 = laundryKiloan.getKiloan(JenisKiloan.kiloanRegular);
        kiloan1.jenisLaundry();
        kiloan1.harga();

        Kiloan kiloan2 = laundryKiloan.getKiloan(JenisKiloan.kiloanEkspress);
        kiloan2.jenisLaundry();
        kiloan2.harga();
    }
}

public class FactoryLaundry {
    public static final String pilih_sepatu = "memilih laundry";
    public static final String pilih_kiloan = "memilih kiloan";

    public static AbstractFactory getFactory(String pilihan) {
        if(pilihan.equals(pilih_sepatu)) {
            return new LaundrySepatu();
        } else if(pilihan.equals(pilih_kiloan)){
            return new LaundryKiloan();
        }

        return null;
    }
}

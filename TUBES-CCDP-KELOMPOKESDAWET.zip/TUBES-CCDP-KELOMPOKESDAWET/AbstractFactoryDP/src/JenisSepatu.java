public class JenisSepatu {
    public static final String sepatuRegular = "Sepatu Regular";
    public static final String sepatuEkspress = "Sepatu Ekspress";
}

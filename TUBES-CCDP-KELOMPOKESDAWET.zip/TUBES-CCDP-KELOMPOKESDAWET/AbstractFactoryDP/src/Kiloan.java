public interface Kiloan {
    void jenisLaundry();
    void harga();
}

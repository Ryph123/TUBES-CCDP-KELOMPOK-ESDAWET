public class SepatuEkspress implements Sepatu {
    private String jenisSepatu = SepatuEkspress.class.getSimpleName();


    @Override
    public void jenisLaundry() {
        System.out.println("Jenis Laundry : "+jenisSepatu);
    }

    @Override
    public void harga() {
        System.out.println("Harga Laundry: RP. 100.0000 / pasang");
    }
}

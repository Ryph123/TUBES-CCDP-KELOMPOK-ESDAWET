public class JenisKiloan {
    public static final String kiloanRegular = "Kiloan Regular";
    public static final String kiloanEkspress = "Kiloan Ekspress";
}

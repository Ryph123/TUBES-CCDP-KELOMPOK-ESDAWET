public abstract class AbstractFactory {
    abstract Sepatu getSepatu(String sepatu);
    abstract Kiloan getKiloan(String kiloan);
}

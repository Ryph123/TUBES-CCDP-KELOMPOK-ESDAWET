public class SepatuRegular implements Sepatu {
    private String jenisSepatu = SepatuRegular.class.getSimpleName();


    @Override
    public void jenisLaundry() {
        System.out.println("Jenis Laundry: "+jenisSepatu);
    }

    @Override
    public void harga() {
        System.out.println("Harga Laundry: RP. 35.000 / pasang");
    }
}

public class LaundrySepatu extends AbstractFactory {

    @Override
    Sepatu getSepatu(String sepatu) {
        if(sepatu.equals(JenisSepatu.sepatuRegular)) {
            return new SepatuRegular();
        } else if(sepatu.equals(JenisSepatu.sepatuEkspress)){
            return new SepatuEkspress();
        }

        return null;
    }

    @Override
    Kiloan getKiloan(String kiloan) {
        return null;
    }
}

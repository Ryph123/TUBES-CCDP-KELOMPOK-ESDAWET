public class KiloanRegular implements Kiloan {
    private String namaLaundry = KiloanRegular.class.getSimpleName();

    @Override
    public void jenisLaundry() {
        System.out.println("Jenis Laundry : "+namaLaundry);
    }

    @Override
    public void harga() {
        System.out.println("Harga Laundry : RP.6000 / Kg");
    }
}

public interface Sepatu {
    void jenisLaundry();
    void harga();
}

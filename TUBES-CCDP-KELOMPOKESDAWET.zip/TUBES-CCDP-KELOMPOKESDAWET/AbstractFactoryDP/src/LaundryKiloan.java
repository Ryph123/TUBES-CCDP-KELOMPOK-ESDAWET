public class LaundryKiloan extends AbstractFactory {

    @Override
    Sepatu getSepatu(String sepatu) {
        return null;
    }

    @Override
    Kiloan getKiloan(String kiloan) {
        if(kiloan.equals(JenisKiloan.kiloanRegular)) {
            return new KiloanRegular();
        } else if(kiloan.equals(JenisKiloan.kiloanEkspress)) {
            return new KiloanEkspress();
        }

        return  null;
    }
}

package ProxyPattern;

public class Folder implements IFolder{
    @Override
    public void performOperations() {
        System.out.println("Kamu sekarang sedang mengakses folder .... ");
    }
}

package ProxyPattern;
public interface IFolder {
    public void performOperations();
}

public class LaundryBuilder {
    public Laundry paket1() {
        Laundry laundry = new Laundry();
        laundry.add(new );
    }
}

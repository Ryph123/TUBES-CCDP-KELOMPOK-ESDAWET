import java.util.ArrayList;
import java.util.List;

public class Laundry {
    private List<Barang> barangList = new ArrayList<>();

    public void add(Barang barang) {barangList.add(barang);}

    public int getHarga() {
        int harga = (int) 0.0f;
        for(Barang barang: barangList){
            System.out.println("Barang : "+ barang.jenis());
            System.out.println("Harga:  "+barang.harga());
        }
    }
}

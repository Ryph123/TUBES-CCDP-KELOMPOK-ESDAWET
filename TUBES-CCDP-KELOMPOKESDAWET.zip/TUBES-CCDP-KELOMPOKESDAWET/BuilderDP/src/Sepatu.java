public abstract class Sepatu implements Barang {
    @Override
    public Packing bungkus() {
        return new Plastik();
    }

    @Override
    public abstract int harga();
}

public class Plastik implements Packing {
    @Override
    public String bungkus() {
        System.out.println("Plastik Laundry");
    }
}

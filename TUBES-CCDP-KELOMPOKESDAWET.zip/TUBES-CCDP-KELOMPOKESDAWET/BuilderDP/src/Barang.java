public interface Barang {
    public String jenis();
    public Packing bungkus();
    public int harga();
}

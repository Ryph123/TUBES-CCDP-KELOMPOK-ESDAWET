public interface Packing {
    public String bungkus();
}

public class PaketSuperExpress extends Paket {

    public PaketSuperExpress(){
        type = "Paket Super Express = 15000";
    }

    @Override
    public void draw() {
        System.out.println("Inside Rectangle::draw() method.");
    }
}
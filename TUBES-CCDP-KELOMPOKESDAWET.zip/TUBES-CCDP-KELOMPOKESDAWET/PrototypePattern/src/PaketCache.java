import java.util.Hashtable;

public class PaketCache {

    private static Hashtable<String, Paket> paketMap  = new Hashtable<String, Paket>();

    public static Paket getShape(String paketId) {
        Paket cachedShape = paketMap.get(paketId);
        return (Paket) cachedShape.clone();
    }

    // for each shape run database query and create shape
    // shapeMap.put(shapeKey, shape);
    // for example, we are adding three shapes

    public static void loadCache() {
        PaketNormal pn = new PaketNormal();
        pn.setId("1");
        paketMap.put(pn.getId(),pn);

        PaketExpress pe = new PaketExpress();
        pe.setId("2");
        paketMap.put(pe.getId(),pe);

        PaketSuperExpress pse = new PaketSuperExpress();
        pse.setId("3");
        paketMap.put(pse.getId(),pse);

    }
}
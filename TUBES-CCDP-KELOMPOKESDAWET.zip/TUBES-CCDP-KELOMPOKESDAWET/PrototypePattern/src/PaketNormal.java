public class PaketNormal extends Paket {

    public PaketNormal(){
        type = "Paket Normal = 6000";
    }

    @Override
    public void draw() {
        System.out.println("Inside Rectangle::draw() method.");
    }
}
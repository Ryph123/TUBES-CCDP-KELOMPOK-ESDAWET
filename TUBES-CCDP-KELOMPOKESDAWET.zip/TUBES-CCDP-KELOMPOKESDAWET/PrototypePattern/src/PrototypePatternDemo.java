public class PrototypePatternDemo {
    public static void main(String[] args) {
        PaketCache.loadCache();

        Paket clonedShape = (Paket) PaketCache.getShape("1");
        System.out.println("Paket : " + clonedShape.getType());

        Paket clonedShape2 = (Paket) PaketCache.getShape("2");
        System.out.println("Paket : " + clonedShape2.getType());

        Paket clonedShape3 = (Paket) PaketCache.getShape("3");
        System.out.println("Paket : " + clonedShape3.getType());
    }
}
public class PaketExpress extends Paket {

    public PaketExpress(){
        type = "Paket Express = 10000";
    }

    @Override
    public void draw() {
        System.out.println("Inside Rectangle::draw() method.");
    }
}
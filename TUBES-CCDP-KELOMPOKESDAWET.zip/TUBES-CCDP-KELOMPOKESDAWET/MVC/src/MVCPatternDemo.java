public class MVCPatternDemo {
    public static void main(String[] args) {


        Pegawai model  = retrivePegawaiFromDatabase();


        PegawaiView view = new PegawaiView();

        PegawaiController controller = new PegawaiController(model, view);

        controller.updateView();


        controller.setPegawaiName("John");

        controller.updateView();
    }

    private static Pegawai retrivePegawaiFromDatabase(){
        Pegawai pegawai = new Pegawai();
        pegawai.setName("Robert");
        pegawai.setRollNo("10");
        return pegawai;
    }
}

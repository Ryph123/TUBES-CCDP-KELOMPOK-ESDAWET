public class PegawaiView {
    public void printPegawaiDetails(String pegawaiName, String pegawaiRollNo){
        System.out.println("Pegawai: ");
        System.out.println("Name: " + pegawaiName);
        System.out.println("Roll No: " + pegawaiRollNo);
    }
}

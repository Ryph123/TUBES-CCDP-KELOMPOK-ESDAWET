public class PegawaiController {

    private Pegawai model;
    private PegawaiView view;

    public PegawaiController(Pegawai model, PegawaiView view){
        this.model = model;
        this.view = view;
    }

    public void setPegawaiName(String name){
        model.setName(name);
    }

    public String getPegawaiName(){
        return model.getName();
    }

    public void setPegawaiRollNo(String rollNo){
        model.setRollNo(rollNo);
    }

    public String getPegawaiRollNo(){
        return model.getRollNo();
    }


    public void updateView(){
        view.printPegawaiDetails(model.getName(), model.getRollNo());
    }

}

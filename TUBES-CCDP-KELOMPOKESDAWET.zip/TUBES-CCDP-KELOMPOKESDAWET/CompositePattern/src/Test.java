public class Test {
    public static void main(String[] args){

        Karyawan pemilik = new Karyawan("Agung ","Pemilik",7000000);

        Karyawan kepalaBagianCuci = new Karyawan("Susi", "Kepala Bagian Cuci",5000000);

        Karyawan kepalaBagianSetrika = new Karyawan("Jaenap","Kepala Bagian Setrika",5000000);

        Karyawan cuci1 = new Karyawan("Andri","Pegawai Cuci",3000000);
        Karyawan cuci2 = new Karyawan("Luna","Pegawai Cuci",3000000);

        Karyawan setrika1 = new Karyawan("Inka","Pegawai Setrika",3000000);
        Karyawan setrika2 = new Karyawan("Novi","Pegawai Setrika",3000000);

        pemilik.add(kepalaBagianCuci);
        pemilik.add(kepalaBagianSetrika);

        kepalaBagianCuci.add(cuci1);
        kepalaBagianCuci.add(cuci2);

        kepalaBagianSetrika.add(setrika1);
        kepalaBagianSetrika.add(setrika2);

        System.out.println(pemilik);

        for(Karyawan headKaryawan : pemilik.getSubordinates()){
            System.out.println();
            System.out.println(headKaryawan);

            for(Karyawan Karyawan : headKaryawan.getSubordinates()){
                System.out.println(" - "+Karyawan);
            }
        }
    }
}
public class PaketNormal extends Observer{
    public PaketNormal(Subject subject) {
        super(subject);
        this.subject.attach(this);
    }

    @Override
    public void update() {
        System.out.println("Paket Normal: "+subject.getHarga());
    }
}

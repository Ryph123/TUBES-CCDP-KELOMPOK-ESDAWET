public class ObserverPatternDemo {
    public static void main(String[] args) {
        Subject PaketNormal = new Subject();
        Subject PaketExpress = new Subject();
        Subject PaketSuperExpress = new Subject();

        new PaketNormal(PaketNormal);
        new PaketExpress(PaketExpress);
        new PaketSuperExpress(PaketSuperExpress);

        PaketNormal.setHarga(6000);
        PaketExpress.setHarga(10000);
        PaketSuperExpress.setHarga(15000);

    }
}
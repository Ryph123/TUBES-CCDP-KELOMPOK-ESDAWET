public class PaketExpress extends Observer{
    public PaketExpress(Subject subject) {
        super(subject);
        this.subject.attach(this);
    }

    @Override
    public void update() {
        System.out.println("Paket Express: "+subject.getHarga());
    }
}

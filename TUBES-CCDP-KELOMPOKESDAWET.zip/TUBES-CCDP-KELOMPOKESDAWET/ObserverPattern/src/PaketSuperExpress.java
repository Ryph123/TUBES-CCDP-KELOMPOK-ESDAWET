public class PaketSuperExpress extends Observer{
    public PaketSuperExpress(Subject subject) {
        super(subject);
        this.subject.attach(this);
    }

    @Override
    public void update() {
        System.out.println("Paket Super Express: "+subject.getHarga());
    }
}

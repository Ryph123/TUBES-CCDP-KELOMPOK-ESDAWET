public class MainClass {
    public static void main(String[] args) {
        BajuAdapter bajuAdapter = new BajuAdapter();
        SepatuAdapter sepatuAdapter = new SepatuAdapter();

        bajuAdapter.jenisSetrika();
        bajuAdapter.harga();
        System.out.println("-------------------");
        sepatuAdapter.jenisLaundry();
        sepatuAdapter.harga();
    }
}

public interface Setrika {
    void jenisSetrika();
    void harga();
}

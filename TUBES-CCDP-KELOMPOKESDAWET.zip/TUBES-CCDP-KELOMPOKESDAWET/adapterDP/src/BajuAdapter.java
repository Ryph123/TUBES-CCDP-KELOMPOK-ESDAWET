
public class BajuAdapter implements Setrika {
    @Override
    public void jenisSetrika() {
        System.out.println("Setrika Cepat");
    }

    @Override
    public void harga() {
        System.out.println("Harga RP. 500 / pcs");
    }
}

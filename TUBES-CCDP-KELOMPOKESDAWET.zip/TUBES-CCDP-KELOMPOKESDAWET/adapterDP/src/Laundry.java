public interface Laundry {
    void jenisLaundry();
    void harga();
}

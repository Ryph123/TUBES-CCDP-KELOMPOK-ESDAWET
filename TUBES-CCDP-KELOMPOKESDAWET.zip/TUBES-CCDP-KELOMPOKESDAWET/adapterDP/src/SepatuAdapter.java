public class SepatuAdapter implements Laundry {
    @Override
    public void jenisLaundry() {
        System.out.println("Sepatu Ekspress");
    }

    @Override
    public void harga() {
        System.out.println("RP. 35.000 / pasang");
    }
}

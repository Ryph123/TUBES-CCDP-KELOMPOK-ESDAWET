public class TestingSepatu {
    public static void main(String[] args){

        Sepatu s1 = Sepatu.getInstance();
        Sepatu s2 = Sepatu.getInstance();
        Sepatu s3 = Sepatu.getInstance();

    }
}

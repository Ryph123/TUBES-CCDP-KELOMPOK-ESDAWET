public class Sepatu {
    private static Sepatu singleton = new Sepatu();

    private Sepatu(){
        System.out.println("Sepatu Reguler Harga: 35.000 ");
    }

    public static Sepatu getInstance() {
        return singleton;
    }
}

public class Chatbot {
    private Laundry cuci;
    private Laundry setrika;
    private Laundry sepatu;

    public Chatbot() {
        sepatu = new Sepatu();
        setrika = new Setrika();
        cuci = new Cuci();
    }

    public void responseTextMessage(String message) {
        switch (message) {
            case "sepatu" :
                System.out.println("Kakak ingin laundry sepatu, berikut list yang aku sediakan:");
                sepatu.kodeLaundry();
                sepatu.jenisLaundry();
                sepatu.harga();
                break;
            case "setrika" :
                System.out.println("Kakak ingin laundry setrika aja, berikut list yang aku sediakan:");
                setrika.kodeLaundry();
                setrika.jenisLaundry();
                setrika.harga();
                break;
            case "cuci" :
                System.out.println("Kakak ingin laundry cuci, berikut list yang aku sediakan:");
                cuci.kodeLaundry();
                cuci.jenisLaundry();
                cuci.harga();
                break;
            default:
                System.out.println("Maaf kak untuk yang lain belum ada, silahkan tanyakan yang ada dulu..");
        }
    }
}

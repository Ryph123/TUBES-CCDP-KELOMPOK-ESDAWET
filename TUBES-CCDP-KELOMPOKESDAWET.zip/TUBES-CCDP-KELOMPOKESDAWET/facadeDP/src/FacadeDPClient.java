import java.util.Scanner;

public class FacadeDPClient {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String inputMessage = "";
        Chatbot chatbot = new Chatbot();

        System.out.println("Halo kak, mau laundry apa?");
        System.out.println("Yang aku sediakan sepatu/setrika/cuci");

        while (!inputMessage.equals("keluar")) {
            inputMessage = scanner.nextLine();
            chatbot.responseTextMessage(inputMessage);
        }
    }
}

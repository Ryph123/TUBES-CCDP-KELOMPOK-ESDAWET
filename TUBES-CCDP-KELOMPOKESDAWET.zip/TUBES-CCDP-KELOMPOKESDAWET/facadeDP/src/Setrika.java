public class Setrika implements Laundry {

    @Override
    public void kodeLaundry() {
        System.out.println("Kode Laundry: SE001");
    }

    @Override
    public void jenisLaundry() {
        System.out.println("Jenis Laundry: Setrika per pcs");
    }

    @Override
    public void harga() {
        System.out.println("Harga Laundry: RP. 500 / pcs");
    }
}

public class Sepatu implements Laundry {

    @Override
    public void kodeLaundry() {
        System.out.println("Kode Laundry : S001");
    }

    @Override
    public void jenisLaundry() {
        System.out.println("Jenis Laundry : Sepatu Reguler");
    }

    @Override
    public void harga() {
        System.out.println("Harga : RP. 35.0000 / 3 days");
    }
}

public class Cuci implements Laundry {

    @Override
    public void kodeLaundry() {
        System.out.println("Kode Laundry: C001");
    }

    @Override
    public void jenisLaundry() {
        System.out.println("Jenis Laundry: CUCI KILOAN");
    }

    @Override
    public void harga() {
        System.out.println("Harga Laundry: RP. 6000 / Kg");
    }
}
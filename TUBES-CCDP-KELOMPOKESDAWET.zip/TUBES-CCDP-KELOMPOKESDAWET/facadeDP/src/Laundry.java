public interface Laundry {
    void kodeLaundry();
    void jenisLaundry();
    void harga();
}
